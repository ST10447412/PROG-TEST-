//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int[] someNums = {20, 5, 15, 10, 3, 17, 7};
        int a = 1;
        while (a < someNums.length) {
            int temp = someNums[a];
            int b = a - 1;
            while (b >= 0 && someNums[b] > temp) {
                someNums[b + 1] = someNums[b];
                --b;

            }
            someNums[b + 1] = temp;
            a++;

            System.out.println("Numbers: " + someNums[a]);
        }

    }
}