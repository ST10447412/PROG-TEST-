import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        //i.
        String[] strArr;
        //ii.
        strArr = new String[10];
        String names =
        //iii.
        for(int i = 0; i < strArr.length;i++)
        {
            System.out.println("//" +Arrays.toString(strArr));
        }
        //iv.
        for(int i = 0; i < strArr.length-1;i--)

        {
            System.out.println("Element :" +Arrays.toString(strArr));
        }


    }
}
