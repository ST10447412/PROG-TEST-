import java.util.Arrays;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // DECLARE AND ASSIGN ELEMENTS
        int[] someNums = {10, 5, 20, 25, 29, 27, 22, 12, 8};

        //FOR LOOPS TO CHECK ELEMENTS
        for (int i = 0; i < someNums.length; i++)
            for (int j = 0; j < someNums.length - 1; j++)

            {
                // IF STATEMENT TO SWAP ELEMENTS IF IN THE WRONG ORDER
                if (someNums[j] > someNums[j + 1]) {
                    int temp = someNums[j];
                    someNums[j] = someNums[j + 1];
                    someNums[j + 1] = temp;

                }

                //DISPLAY ELEMENTS IN ASCENDING ORDER
                System.out.println("Numbers: " + Arrays.toString(someNums));
            }
    }
}